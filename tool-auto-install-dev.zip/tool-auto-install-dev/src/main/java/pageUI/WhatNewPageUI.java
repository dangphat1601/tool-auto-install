package pageUI;

public class WhatNewPageUI {

    public static final String UNHAPPY_REACTION = "//a[contains(@title, '%s')]/ancestor::article//img[@alt='unhappy']";
    public static final String NEUTRAL_REACTION = "//a[contains(@title, '%s')]/ancestor::article//img[@alt='neutral']";
    public static final String HAPPY_REACTION = "//a[contains(@title, '%s')]/ancestor::article//img[@alt='happy']";


}
